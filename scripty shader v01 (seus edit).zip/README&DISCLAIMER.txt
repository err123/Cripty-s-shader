!!!!!!! DISCLAIMER !!!!!!!!!
"I DO NOT OWN" any of these code nor im the official owner of shader
Im just a man having fun with shader, AND DO NOT WANT ANY PROFIT out of these codes / shader
i just love to share what i've change/edit to people.

just remember that if you want to do a review, credit me, and Don't forget to credit Cody arr too a.k.a sonic either.




























































follow the seus shader rules too! :)